function SectionOfficeVideo2() {
    return (
        <>
            <h4 className="twm-s-title">Video</h4>
            <div className="video-yt-section">
                <iframe title="Envato Visits Their New Office" width={660} height={371} src="https://www.youtube.com/embed/SZEflIVnhH8?feature=oembed" />
            </div>
        </>
    )
}

export default SectionOfficeVideo2;