import AppRoutes from "../routing/app-routes";

function RootLayout() {

    return <AppRoutes />;
}

export default RootLayout;