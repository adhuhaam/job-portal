// View all demos button function by = custom.js
// function twm_view_all_demo_btn(){
    jQuery('#all-demo-open, .all-demo-close').click(function () {
        jQuery('.twm-all-demo-list-wrap').toggleClass('active');
    });
// }